from __future__ import print_function
import pandas as pd
import numpy as np
import os
import string
import pickle
import copy
waitingcost=24
chargingcost=100
unloadtime=0.5
############################################################################################
#######################################node class###########################################
############################################################################################
class NODE:#depot, customer, or charging node
    def __init__(self,ID,node_type,lng,lat,edge_d,edge_t,w=-1,v=-1,t_l=-1,t_h=-1,charge_node=-1,charge_time=-1,charge_distance=-1):
        self.ID=ID
        self.node_type=node_type
        self.w=w
        self.v=v
        self.t_l=t_l
        self.t_h=t_h
        self.lng=lng
        self.lat=lat
        self.edge_d=edge_d
        self.edge_t=edge_t
        self.charge_node=charge_node
        self.charge_time=charge_time
        self.charge_distance=charge_distance
        self.fullfilled=False
        return
    def print_data(self):
        print("ID=",end="")
        print(self.ID)
        print("node_type=",end="")
        print(self.node_type)
        print("w=",end="")
        print(self.w)
        print("v=",end="")
        print(self.v)
        print("t_l=",end="")
        print(self.t_l)
        print("t_h=",end="")
        print(self.t_h)
        print("lng=",end="")
        print(self.lng)
        print("lat=",end="")
        print(self.lat)
        print("edge_d=",end="")
        print(self.edge_d)
        print("edge_t=",end="")
        print(self.edge_t)
#################################################################################################
#######################################vehicle classes###########################################
#################################################################################################
class VEHICLE_1:#vehicle type 1
    def __init__(self):
        self.max_v=12
        self.max_w=2
        self.max_range=100000
        self.charge_t=0.5
        self.trans_cost=12/1000
        self.vecicle_c=200
        self.node=[]
        self.t=8
        self.cost=200
        self.range=0
        self.v=0
        self.w=0
        return
    def print_data(self):
        print("Type=",end="")
        print(1)
        #print("Range(max=100000)=",end="")
        #print(self.range)
        print("Cost=",end="")
        print(self.cost)
        print("Volumn(max=12)=",end="")
        print(self.v)
        print("Weight(max=2)=",end="")
        print(self.w)
        print("t(max=24)=",end="")
        print(self.t)
        print("Nodes=",end="")
        for i in self.node:
            print(i.ID,end=" ")
        print(" ")

class VEHICLE_2:#vehicle type 2
    def __init__(self):
        self.max_v=16
        self.max_w=2.5
        self.max_range=120000
        self.charge_t=0.5
        self.trans_cost=14/1000
        self.vecicle_c=300
        self.node=[]
        self.t=8
        self.cost=300
        self.range=0
        self.v=0
        self.w=0
        return
    def print_data(self):
        print("Type=",end="")
        print(2)
        #print("Range(max=120000)=",end="")
        #print(self.range)
        print("Cost=",end="")
        print(self.cost)
        print("Volumn(max=16)=",end="")
        print(self.v)
        print("Weight(max=2.5)=",end="")
        print(self.w)
        print("t(max=24)=",end="")
        print(self.t)
        print("Nodes=",end="")
        for i in self.node:
            print(i.ID,end=" ")
        print(" ")
#####################################################################################################
#######################################auxiliary functions###########################################
#####################################################################################################
def load_edge(filename):
    edge=pd.read_csv(filename)
    edge=edge.values
    return edge[:,1:]

def load_node(filename):
    node=pd.read_csv(filename)
    node=node.values
    return node[:,1:]

def time2double(time):
    time=time.split(":")
    time=int(time[0])+int(time[1])/60.0
    return time

def node_distance(node1,node2):
    id1=node1.ID
    id2=node2.ID
    if id1<id2:
        return node2.edge_d[id1]
    elif id1>id2:
        return node1.edge_d[id2]
    else:
        return 0

def node_time(node1,node2):
    id1=node1.ID
    id2=node2.ID
    if id1<id2:
        return node2.edge_t[id1]
    elif id1>id2:
        return node1.edge_t[id2]
    else:
        return 0
##############################################################################################################
#######################################checkers for greedy algorism###########################################
##############################################################################################################
def feasible(veh,last_node,next_node,notabu=True):#if the route from one node to another (customer) is feasible
    flag=True
    if veh.range+node_distance(last_node,next_node)+next_node.edge_d[0]>veh.max_range:
        if veh.range+node_distance(last_node,next_node)+next_node.charge_distance>veh.max_range:
            #print("Exceed distance error!")
            flag=False
            return flag
    if veh.t+node_time(last_node,next_node)>next_node.t_h:
        #print("Exceed time error!")
        flag=False
        return flag
    if veh.t+node_time(last_node,next_node)+unloadtime+next_node.edge_t[0]>24:
        #print("Exceed time error!")
        flag=False
        return flag
    if (veh.v+next_node.v>veh.max_v)|(veh.w+next_node.w>veh.max_w):
        #print("Exceed weight/volumn error!")
        #veh.print_data()
        flag=False
        return flag
    if notabu:
        if next_node in veh.node:
            #print("Node already exist error!")
            flag=False
            return flag
    return flag

def feasible_charge(veh,last_node,next_node,chargetime=0.5):#if the route from one node to another (charging pile) is feasible
    flag=True
    if veh.range+node_distance(last_node,next_node)>veh.max_range:
        flag=False
        #print("Charge range error!")
        return flag
    if veh.t+node_time(last_node,next_node)+chargetime+next_node.edge_t[0]>24:
        flag=False
        #print("Charge time error!")
        return flag
    return flag

def feasible_firstnode(veh,node):
    flag=True
    if veh.t+node.edge_t[0]>node.t_h:
        #print("Time error (first node)!")
        flag=False
        return flag
    if veh.t+2*node.edge_t[0]+unloadtime>24:
        #print("Time error (first node)!")
        flag=False
        return flag
    if (veh.max_v<node.v)|(veh.max_w<node.w):
        #print("Weight/volumn error (first node)!")
        flag=False
        return flag
    return flag

def decide_charge(veh,last_node,nodelist,charge_max_t,charge_min_v,charge_min_w):#decide whether and where to charge
    #veh.print_data()
    if (veh.range+last_node.edge_d[0]>veh.max_range)&(veh.range+last_node.charge_distance>veh.max_range):
        print("Charge error!")
    if veh.range+last_node.edge_d[0]>veh.max_range:
        return 1
    if veh.range+last_node.charge_distance>veh.max_range:
        return 0
    #if ~feasible_charge(veh,last_node,nodelist[last_node.charge_node]):
        #return -1
    if veh.t>charge_max_t:
        return -1
    if (veh.v/veh.max_v>charge_min_v)|(veh.w/veh.max_w>charge_min_w):
        return 0
    else:
        return 1

def find_first_node(veh,target_node,nodelist,first_time=False):
    min_time=10000000
    for i in target_node:
        if (feasible_firstnode(veh,i))&(~(i in veh.node)):
            time=max(i.edge_t[0],i.t_l-veh.t)
            if time<min_time:
                min_time=time
                first_node=i
    if min_time==10000000:
        return veh,target_node,0
    veh.node.append(nodelist[0])
    veh.node.append(first_node)
    veh.range=veh.range+first_node.edge_d[0]
    if first_node.t_l<veh.t+first_node.edge_t[0]:
        veh.t=veh.t+first_node.edge_t[0]
        veh.cost=veh.cost+first_node.edge_d[0]*veh.trans_cost
    elif first_time:
        veh.t=first_node.t_l
        veh.cost=veh.cost+first_node.edge_d[0]*veh.trans_cost
    else:
        veh.cost=veh.cost+(first_node.t_l-veh.t-first_node.edge_t[0])*waitingcost
        veh.t=first_node.t_l
        veh.cost=veh.cost+first_node.edge_d[0]*veh.trans_cost
    veh.t=veh.t+unloadtime
    veh.v=veh.v+first_node.v
    veh.w=veh.w+first_node.w
    target_node.remove(i)
    return veh,target_node,1

def find_route_onecharge(veh,target_node,nodelist,frombase=True,first_time=False):
    if frombase:
        veh,target_node,flag=find_first_node(veh,target_node,nodelist,first_time)
        if flag==0:
            return veh,target_node,-1
    else:
        flag=0
    while(True):
        last_node=veh.node[-1]
        feasible_list=[]
        for i in target_node:
            if (feasible(veh,last_node,i)==True)&((veh.range+node_distance(last_node,i)+i.edge_d[0]<=veh.max_range)|(veh.range+node_distance(last_node,i)+i.charge_distance<=veh.max_range)&(i not in veh.node)):
                feasible_list.append(i)
        if len(feasible_list)==0:
            break
        min_time=10000000
        for i in feasible_list:
            time=max(node_time(i,last_node),i.t_l-veh.t)
            if time<min_time:
                min_time=time
                next_node=i
        if veh.range+node_distance(last_node,next_node)+next_node.edge_d[0]>veh.max_range:
            return veh,target_node,flag
        flag=flag+1
        veh.node.append(next_node)
        if next_node.t_l<veh.t+node_time(next_node,last_node):
            veh.t=veh.t+node_time(next_node,last_node)
            veh.cost=veh.cost+node_distance(next_node,last_node)*veh.trans_cost
        else:
            veh.cost=veh.cost+(next_node.t_l-veh.t-node_time(next_node,last_node))*waitingcost
            veh.t=next_node.t_l
            veh.cost=veh.cost+node_distance(next_node,last_node)*veh.trans_cost
        veh.t=veh.t+unloadtime
        veh.range=veh.range+node_distance(next_node,last_node)
        veh.v=veh.v+next_node.v
        veh.w=veh.w+next_node.w
        target_node.remove(next_node)
    return veh,target_node,flag

def find_route(veh,target_node,nodelist,charge_max_t,charge_min_v,charge_min_w):
    veh,target_node,flag=find_route_onecharge(veh,target_node,nodelist,True,True)
    if flag==-1:
        return -1
    flag2=0
    if len(target_node)==0:
        flag=0
        last_node=veh.node[-1]
        if veh.range+last_node.edge_d[0]>veh.max_range:
            if veh.range+last_node.charge_distance>veh.max_range:
                print("Find route range error!")
            else:
                veh.cost=veh.cost+chargingcost*0.5+last_node.charge_distance*veh.trans_cost
                veh.range=0
                veh.t=veh.t+last_node.charge_time
                veh.node.append(nodelist[last_node.charge_node])
    while(flag!=0):
        flag2=flag2+1
        last_node=veh.node[-1]
        if flag2==20:
            print(veh.range+last_node.edge_d[0])
            print(last_node.charge_distance)
            veh.print_data()
        decide=decide_charge(veh,last_node,nodelist,charge_max_t,charge_min_v,charge_min_w)
        if decide==-1:
            veh.cost=veh.cost+last_node.edge_d[0]*veh.trans_cost
            veh.node.append(nodelist[0])
            veh.t=veh.t+last_node.edge_t[0]
            veh.range=veh.range+last_node.edge_d[0]
            return veh
        elif decide==0:
            veh.t=veh.t+last_node.edge_t[0]+1
            veh.w=0
            veh.v=0
            veh.cost=veh.cost+last_node.edge_d[0]*veh.trans_cost+waitingcost
            veh.range=0
            veh,target_node,flag3=find_route_onecharge(veh,target_node,nodelist,True)
            if flag3<=0:
                veh.cost=veh.cost-waitingcost-last_node.edge_d[0]*veh.trans_cost
                veh.t=veh.t-last_node.edge_t[0]-1
                break
        else:
            veh.t=veh.t+last_node.charge_time
            veh.cost=veh.cost+chargingcost*0.5+last_node.charge_distance*veh.trans_cost
            veh.range=0
            veh.node.append(nodelist[last_node.charge_node])
            veh,target_node,flag3=find_route_onecharge(veh,target_node,nodelist,False)
        if flag3<=0:
            break
    last_node=veh.node[-1]
    veh.cost=veh.cost+last_node.edge_d[0]*veh.trans_cost
    veh.node.append(nodelist[0])
    veh.t=veh.t+last_node.edge_t[0]
    return veh
#########################################################################################################
#######################################checker for tabu search###########################################
#########################################################################################################
def feasible_first_node_tabu(veh,from_index,nodelist,first_time=False):
    first_node=veh.node[from_index]
    if first_node.node_type==1:
        return veh,True
    if first_node.node_type==3:
        veh.range=0
        veh.t=veh.t+first_node.edge_t[0]+0.5
        veh.cost=veh.cost+first_node.edge_d[0]*veh.trans_cost+chargingcost*0.5
        return veh,True
    if (veh.t+first_node.edge_t[0]>first_node.t_h)|(veh.v+first_node.v>veh.max_v)|(first_node.w+veh.w>veh.max_w):
        return veh,False
    veh.range=veh.range+first_node.edge_d[0]
    if first_node.t_l<veh.t+first_node.edge_t[0]:
        veh.t=veh.t+first_node.edge_t[0]
        veh.cost=veh.cost+first_node.edge_d[0]*veh.trans_cost
    elif first_time:
        veh.t=first_node.t_l
        veh.cost=veh.cost+first_node.edge_d[0]*veh.trans_cost
    else:
        veh.cost=veh.cost+(first_node.t_l-veh.t-first_node.edge_t[0])*waitingcost
        veh.t=first_node.t_l
        veh.cost=veh.cost+first_node.edge_d[0]*veh.trans_cost
    veh.t=veh.t+unloadtime
    veh.v=veh.v+first_node.v
    veh.w=veh.w+first_node.w
    return veh,True

def feasible_route_onecharge_tabu(veh,from_index,nodelist,frombase=True,first_time=False):
    if frombase:
        veh,flag=feasible_first_node_tabu(veh,from_index,nodelist,first_time)
        from_index=from_index+1
        if flag==False:
            return veh,-1
    else:
        flag=True
    while(flag):
        if from_index==len(veh.node)-1:
            return veh,-2
        if from_index>len(veh.node)-1:
            return veh,-1
        last_node=veh.node[from_index-1]
        next_node=veh.node[from_index]
        if next_node.node_type!=2:
            break
        if feasible(veh,last_node,next_node,False)==False:
            #veh.print_data()
            #print(last_node.ID,next_node.ID)
            #print(last_node.v,next_node.v)
            #print(last_node.w,next_node.w)
            #print("Not feasible!")
            #print("#####################################")
            return veh,-1
        if veh.range+node_distance(last_node,next_node)+next_node.edge_d[0]>veh.max_range:
            if veh.range+node_distance(last_node,next_node)+next_node.charge_distance>veh.max_range:
                print("fatal error!")
                return veh,-1
        if next_node.t_l<veh.t+node_time(next_node,last_node):
            veh.t=veh.t+node_time(next_node,last_node)
            veh.cost=veh.cost+node_distance(next_node,last_node)*veh.trans_cost
        else:
            veh.cost=veh.cost+(next_node.t_l-veh.t-node_time(next_node,last_node))*waitingcost
            veh.t=next_node.t_l
            veh.cost=veh.cost+node_distance(next_node,last_node)*veh.trans_cost
        veh.t=veh.t+unloadtime
        veh.range=veh.range+node_distance(next_node,last_node)
        veh.v=veh.v+next_node.v
        veh.w=veh.w+next_node.w
        from_index=from_index+1
    return veh,from_index

def feasible_route_tabu(veh,nodelist):
    if (veh.node[0].ID>0)|(veh.node[-1].ID>0):
        return -1
    from_index=1
    veh,from_index=feasible_route_onecharge_tabu(veh,from_index,nodelist,frombase=True,first_time=True)
    while(True):
        if from_index==-1:
            #print("No feasible first node!")
            return -1
        if from_index==-2:
            last_node=veh.node[-2]
            veh.cost=veh.cost+last_node.edge_d[0]*veh.trans_cost
            veh.t=veh.t+last_node.edge_t[0]
            veh.range=veh.range+last_node.edge_d[0]
            if veh.range>veh.max_range:
                #print("Exceed max range!")
                return -1
            if veh.t>24:
                #print("Exceed max t!")
                return -1
            return veh.cost
        if veh.node[from_index].ID==0:
            last_node=veh.node[from_index-1]
            veh.t=veh.t+last_node.edge_t[0]+1
            veh.range=veh.range+last_node.edge_d[0]
            if veh.range>veh.max_range:
                #print("Exceed max range!")
                return -1
            veh.w=0
            veh.v=0
            #print("reload,",veh.v,veh.w)
            #veh.print_data()
            veh.cost=veh.cost+last_node.edge_d[0]*veh.trans_cost+waitingcost
            veh.range=0
            from_index=from_index+1
            if veh.t>24:
                #print("Exceed max t!")
                return -1
            veh,from_index=feasible_route_onecharge_tabu(veh,from_index,nodelist,frombase=True)
        else:
            last_node=veh.node[from_index-1]
            next_node=veh.node[from_index]
            veh.t=veh.t+node_time(last_node,next_node)+0.5
            if veh.t>24:
                #print("Exceed max t!")
                return -1
            if veh.range+node_distance(last_node,next_node)>veh.max_range:
                #print("Exceed max range!")
                return -1
            veh.cost=veh.cost+chargingcost*0.5+node_distance(last_node,next_node)*veh.trans_cost
            veh.range=0
            from_index=from_index+1
            veh,from_index=feasible_route_onecharge_tabu(veh,from_index,nodelist,frombase=False)
    #if veh.range>veh.max_range:
    #    print("Exceed max range3!")
    #    return -1
    #if veh.t>24:
    #    print("Exceed max t!")
    #    return -1
############################################################################################
#######################################graph class##########################################
############################################################################################
class GRAPH:#the class used to save all data and run our algorism
    def __init__(self,edge_file,node_file,save_file,print_file,max_iter,tabu_num):
        self.edge_file=edge_file
        self.node_file=node_file
        self.save_file=save_file
        self.print_file_path=print_file
        self.max_iter=max_iter
        self.best_cost=[1000000000]
        self.best_vehicle=[]
        self.all_cost=[]
        self.tabu_num=tabu_num
        return
    def add_all_node(self):#load node data
        node_list=[]
        edge=load_edge(self.edge_file)
        node=load_node(self.node_file)
        #print(np.size(node,0))
        node_num=np.size(node,0)
        LNG=[]
        LAT=[]
        for i in range(0,node_num):
            node_type=int(node[i,0])
            lng=float(node[i,1])
            lat=float(node[i,2])
            ID=int(i)
            edge_d=edge[1100*i:1100*(i+1),2]
            edge_t=edge[1100*i:1100*(i+1),3]/60
            for index in range(0,1100):
                edge_d[index]=float(edge_d[index])
                edge_t[index]=float(edge_t[index])
            if node_type==2:
                t_l=time2double(node[i,5])
                t_h=time2double(node[i,6])
                w=float(node[i,3])
                v=float(node[i,4])
                edge_d_charge=edge_d[1000:1100]
                charge_node=np.argmin(edge_d_charge)
                charge_node=charge_node+1000
                charge_distance=edge_d[charge_node]
                charge_time=0.5+edge_t[charge_node]
                charge_node=charge_node+1
                LNG.append(lng)
                LAT.append(lat)
                N=NODE(ID,node_type,lng,lat,edge_d,edge_t,w,v,t_l,t_h,charge_node,charge_time,charge_distance)
            else:
                N=NODE(ID,node_type,lng,lat,edge_d,edge_t)
            node_list.append(N)
        self.LNG=LNG
        self.LAT=LAT
        self.node_list=node_list
    def initalize(self):
        self.add_all_node()
        self.vehicle=[]
        self.charge_max_t=16
        self.charge_min_v=0.5
        self.charge_min_w=0.5
        self.weight_v1=1
        self.cost_reduce_list=[10,10,1,1]#prior
        self.all_cost=[]
        print("Initalize done.")
    def reinitialize(self):
        for i in self.node_list:
            i.fullfilled=False
        self.vehicle=[]
    def add_vehicle(self):#for greedy algorism
        target_node1=[]
        target_node2=[]
        for i in self.node_list:
            if (i.node_type==2) & (i.fullfilled==False):
                target_node1.append(i)
                target_node2.append(i)
        if len(target_node1)==0|len(target_node2)==0:
            return -1
        #print("length=",end="")
        #print(len(target_node1))
        #if len(target_node1)<5:
            #print("IDs:",end="")
            #for w in target_node1:
                #print(w.ID,end=" ")
        v1=VEHICLE_1()
        v1=find_route(v1,target_node1,self.node_list,self.charge_max_t,self.charge_min_v,self.charge_min_w)
        v2=VEHICLE_2()
        v2=find_route(v2,target_node2,self.node_list,self.charge_max_t,self.charge_min_v,self.charge_min_w)
        if (type(v1)!=VEHICLE_1)&(type(v2)!=VEHICLE_2):
            print("No vechicle added error!")
            return -1
        if (type(v1)==VEHICLE_1)&(type(v2)==VEHICLE_2):#comprare average cost
            if v2.cost/(len(v2.node)-2)<self.weight_v1*v1.cost/(len(v1.node)-2):
                veh=v2
            else:
                veh=v1
        elif type(v1)==VEHICLE_1:
            veh=v1
        else:
            veh=v2
        for i in veh.node:
            self.node_list[i.ID].fullfilled=True
        self.vehicle.append(veh)
        return 1
    def check(self):#checker, for greedy algorism
        for i in self.node_list:
            if i.node_type==2 & i.fullfilled==False:
                print("check error (node unfullfilled)!")
                return -1
        for j in self.vehicle:
            if j.t>24:
                print("check error (t)!")
                return -1
        print("check passed")
        return 0
    def check_tabu(self):#checker, for tabu search
        node_list=list(range(1,1001))
        for j in self.vehicle:
            if j.t>24|j.range>j.max_range:
                print("Check error (t/range)!")
                return -1
            for i in j.node:
                if i.node_type==2:
                    #print(i.ID)
                    #print(node_list)
                    node_list.remove(i.ID)
        if len(node_list)==0:
            print("check passed")
            return 0
        else:
            print("check error (node unfullfilled)!")
            return -1
    def get_solution(self):#main function for greedy algorism
        #i=1
        #self.clear_max_dis()
        while(True):
            #print(i)
            #i=i+1;
            if self.add_vehicle()==-1:
                break
        cost=0
        for i in self.vehicle:
            cost=cost+i.cost
        return cost
    def run(self):#get initial solution
        self.initalize()
        cost=self.get_solution()
        print("Cost=",end="")
        print(cost)
        self.best_vehicle=copy.deepcopy(self.vehicle)
        self.best_cost=[cost]
        self.all_cost=[cost]
        #self.save_graph()
    def in_tabu_list(self,data):
        length=len(self.tabu_list)
        for i in range(0,length):
            if self.tabu_list[i]==data:
                return 1
        return -1
    def create_veh(self,index):
        if type(self.best_vehicle[index])==VEHICLE_1:
            new_veh=VEHICLE_1()
            new_veh.node=copy.deepcopy(self.best_vehicle[index].node)
        else:
            new_veh=VEHICLE_2()
            new_veh.node=copy.deepcopy(self.best_vehicle[index].node)
        return new_veh
    def run_tabu(self,rerun=True):#main function for tabu search
        if rerun:
            self.initalize()
            cost=self.get_solution()
            self.best_cost=[cost]
            self.best_vehicle=copy.deepcopy(self.vehicle)
        self.tabu_list=[]
        self.print_best_cost()
        
        for i in range(0,self.max_iter):
            veh_num=len(self.best_vehicle)
            p=0
            q=0
            p_node=0
            q_node=0
            if i%100000==0:
                self.cost_reduce_list=[10,10,1,1]
                print("Cost reduce list initialized.")
            if i%20000==0:
                print("Iteration=",end="")
                print(i)
                print("Saving...")
                self.save_graph()
                self.print_file(self.print_file_path)
                self.save_best_cost()
                print("Saved.")
                print("Cost reduce list:",self.cost_reduce_list)
            while (p==q)|(self.in_tabu_list([p,q,p_node,q_node])==1):
                p=np.random.randint(veh_num)
                q=np.random.randint(veh_num)
                veh_p=self.create_veh(p)
                veh_q=self.create_veh(q)
                p_node=np.random.randint(1,len(veh_p.node)-1)
                q_node=np.random.randint(1,len(veh_q.node)-1)
            if veh_p.node[p_node].ID==veh_q.node[q_node].ID:
                continue
            #print(p,q,p_node,q_node)
            rand=np.random.rand()#random sampling
            if rand<self.cost_reduce_list[0]/sum(self.cost_reduce_list):
                #print("Running exchange...")
                self.cost_reduce_list[0]=self.cost_reduce_list[0]+self.run_tabu_exchange(p,q,veh_p,veh_q,p_node,q_node)
            elif rand<(self.cost_reduce_list[0]+self.cost_reduce_list[1])/sum(self.cost_reduce_list):
                #print("Running insert...")
                self.cost_reduce_list[1]=self.cost_reduce_list[1]+self.run_tabu_insert(p,q,veh_p,veh_q,p_node,q_node)
            elif rand<(self.cost_reduce_list[0]+self.cost_reduce_list[1]+self.cost_reduce_list[2])/sum(self.cost_reduce_list):
                charge_node=[]
                for i in range(0,len(veh_p.node)):
                    if veh_p.node[i].node_type==3:
                        charge_node.append(i)
                if len(charge_node)>0:
                    rand_charge=np.random.randint(0,len(charge_node))
                    self.cost_reduce_list[2]=self.cost_reduce_list[2]+self.run_tabu_change_charge(p,veh_p,charge_node[rand_charge])
            else:
                if type(veh_p)==VEHICLE_2:
                    self.cost_reduce_list[3]=self.cost_reduce_list[3]+self.run_tabu_change(p,veh_p)
        self.print_best_cost()
        #self.print_vehicle()
        #self.save_graph()
    def run_tabu_exchange(self,p,q,veh_p,veh_q,p_node,q_node):#operator 1
        reduce_cost=0
        a=veh_p.node[p_node]
        veh_p.node[p_node]=veh_q.node[q_node]
        veh_q.node[q_node]=a
        #veh_p.print_data()
        #veh_q.print_data()
        #print(p,q)
        #print("##################################################")
        #print(veh_p.v,veh_q.v)
        #print(veh_p.w,veh_q.w)
        temp_p=copy.deepcopy(veh_p)
        temp_q=copy.deepcopy(veh_q)
        self.tabu_list.append([p,q,p_node,q_node])
        if len(self.tabu_list)>self.tabu_num:
           self.tabu_list.remove(self.tabu_list[0])
        flag1=feasible_route_tabu(temp_p,self.node_list)
        flag2=feasible_route_tabu(temp_q,self.node_list)
        #print(temp_p.t,temp_q.t)
        if (flag1!=-1)&(flag2!=-1):
            cost=self.best_cost[-1]-self.best_vehicle[p].cost-self.best_vehicle[q].cost+flag1+flag2
            #print(cost)
            self.all_cost.append(cost)
            temp_p.cost=flag1
            temp_q.cost=flag2
            if cost<self.best_cost[-1]:
                reduce_cost=self.best_cost[-1]-cost
                self.best_cost.append(cost)
                print("(Exchange node)",end="")
                self.print_best_cost()
                self.best_vehicle[p]=temp_p
                self.best_vehicle[q]=temp_q
        return reduce_cost
    def run_tabu_insert(self,p,q,veh_p,veh_q,p_node,q_node):#operator 2
        reduce_cost=0
        #veh_p.print_data()
        veh_p.node.insert(p_node,veh_q.node[q_node])
        #veh_p.print_data()
        #veh_q.print_data()
        veh_q.node.remove(veh_q.node[q_node])
        #veh_q.print_data()
        flag0=0
        for i in veh_q.node:
            if i.node_type==2:
                flag0=flag0+1
        self.tabu_list.append([p,q,p_node,q_node])
        if len(self.tabu_list)>self.tabu_num:
            self.tabu_list.remove(self.tabu_list[0])
        if flag0==0:
            temp_p=copy.deepcopy(veh_p)
            flag1=feasible_route_tabu(temp_p,self.node_list)
            if flag1!=-1:
                cost=self.best_cost[-1]-self.best_vehicle[p].cost-self.best_vehicle[q].cost+flag1
                self.all_cost.append(cost)
                #print(cost)
                temp_p.cost=flag1
                if cost<self.best_cost[-1]:
                    reduce_cost=self.best_cost[-1]-cost
                    self.best_cost.append(cost)
                    print("(Delete vehicle)",end="")
                    self.print_best_cost()
                    self.best_vehicle[p]=temp_p
                    self.best_vehicle.remove(self.best_vehicle[q])
            return reduce_cost
        temp_p=copy.deepcopy(veh_p)
        temp_q=copy.deepcopy(veh_q)
        flag1=feasible_route_tabu(temp_p,self.node_list)
        flag2=feasible_route_tabu(temp_q,self.node_list)
        #print(flag1,flag2)
        if (flag1!=-1)&(flag2!=-1):
            cost=self.best_cost[-1]-self.best_vehicle[p].cost-self.best_vehicle[q].cost+flag1+flag2
            #print(cost)
            self.all_cost.append(cost)
            temp_p.cost=flag1
            temp_q.cost=flag2
            if cost<self.best_cost[-1]:
                reduce_cost=self.best_cost[-1]-cost
                self.best_cost.append(cost)
                print("(Insert node)",end="")
                self.print_best_cost()
                self.best_vehicle[p]=temp_p
                self.best_vehicle[q]=temp_q
            return reduce_cost
        return reduce_cost
    def run_tabu_change(self,p,veh_p):#operator 3
        reduce_cost=0
        temp_p=VEHICLE_1()
        temp_p.node=copy.deepcopy(veh_p.node)
        self.tabu_list.append([p,p,p,p])
        if len(self.tabu_list)>self.tabu_num:
           self.tabu_list.remove(self.tabu_list[0])
        flag1=feasible_route_tabu(temp_p,self.node_list)
        if flag1!=-1:
            cost=self.best_cost[-1]-self.best_vehicle[p].cost+flag1
            self.all_cost.append(cost)
            #print(cost)
            temp_p.cost=flag1
            if cost<self.best_cost[-1]:
                reduce_cost=self.best_cost[-1]-cost
                self.best_cost.append(cost)
                print("(Change vehicle)",end="")
                self.print_best_cost()
                self.best_vehicle[p]=temp_p
        return reduce_cost
    def run_tabu_change_charge(self,p,veh_p,charge_node):#operator 4
        reduce_cost=0
        temp_p=copy.deepcopy(veh_p)
        new_charge=np.random.randint(980,1101)
        if new_charge<1001:
            temp_p.node.remove(temp_p.node[charge_node])
        else:
            temp_p.node[charge_node]=copy.deepcopy(self.node_list[new_charge])
        self.tabu_list.append([p,-p,p,-p])
        if len(self.tabu_list)>self.tabu_num:
            self.tabu_list.remove(self.tabu_list[0])
        flag1=feasible_route_tabu(temp_p,self.node_list)
        if flag1!=-1:
            cost=self.best_cost[-1]-self.best_vehicle[p].cost+flag1
            self.all_cost.append(cost)
            #print(cost)
            temp_p.cost=flag1
            if cost<self.best_cost[-1]:
                reduce_cost=self.best_cost[-1]-cost
                self.best_cost.append(cost)
                print("(Change charge node)",end="")
                self.print_best_cost()
                self.best_vehicle[p]=temp_p
        return reduce_cost
    def save_graph(self):
        output = open(self.save_file, 'wb')
        str = pickle.dumps(self)
        output.write(str)
        output.close()
    def print_best_cost(self):
        print("Best cost=",end="")
        print(self.best_cost[-1])
    def save_best_cost(self):#save cost information to file
        np.savez('best_cost.npz',best_cost=self.best_cost,all_cost=self.all_cost)
    def print_para(self):
        print("charge_max_t=",end="")
        print(self.charge_max_t)
        print("charge_min_v=",end="")
        print(self.charge_min_v)
        print("charge_min_w=",end="")
        print(self.charge_min_w)
        print("weight_v1=",end="")
        print(self.weight_v1)
    def print_vehicle(self):
        for i in self.vehicle:
            print("#############################")
            i.print_data()
    def print_file(self,filename,cost=False):#save results to file
        file=open(filename,'w')
        for i in self.best_vehicle:
            if type(i)==VEHICLE_1:
                print(1,end=":",file=file)
                for j in i.node:
                    print(j.ID,end=" ",file=file)
                if cost:
                    print(" ",i.cost,file=file)
                else:
                    print("",file=file)
            if type(i)==VEHICLE_2:
                print(2,end=":",file=file)
                for j in i.node:
                    print(j.ID,end=" ",file=file)
                if cost:
                    print(" ",i.cost,file=file)
                else:
                    print("",file=file)
        return
############################################################################################
#######################################load graph###########################################
############################################################################################
def load_graph(filename,edge_file,node_file,save_file,print_file,max_iter,tabu_num):
    g=GRAPH(edge_file,node_file,save_file,print_file,max_iter,tabu_num)
    with open(filename,'rb') as file:
        g  = pickle.loads(file.read())
    return g
############################################################################################
##########################################main##############################################
############################################################################################
def main(max_iter,tabu_num,run,load,tabu):
    edge_file=os.path.dirname(__file__)+"/input_distance-time.txt"
    node_file=os.path.dirname(__file__)+"/input_node.csv"
    save_file=os.path.dirname(__file__)+"/graph_tabu.pkl"
    print_file=os.path.dirname(__file__)+"/tabu_result.txt"
    add_prefix=0
    if add_prefix:
        edge_file="/home/fengyao/project"+edge_file
        node_file="/home/fengyao/project"+node_file
        save_file="/home/fengyao/project"+save_file
        print_file="/home/fengyao/project"+print_file
    print_flag=1
    if run:
        if load:
            g=load_graph(save_file,edge_file,node_file,save_file,print_file,max_iter,tabu_num)
            if tabu:
                g.run_tabu(False)
                g.check_tabu()
                g.save_graph()
            else:
                g.run()
                g.check()
                #g.print_vehicle()
                g.save_graph()
        else:
            g=GRAPH(edge_file,node_file,save_file,print_file,max_iter,tabu_num)
            if tabu:
                g.run_tabu(True)
                g.check_tabu()
                g.save_graph()
            else:
                g.run()
                g.check()
                #g.print_vehicle()
                g.save_graph()
    else:
        g=load_graph(save_file,edge_file,node_file,save_file,print_file,max_iter,tabu_num)
        g.print_best_cost()
        g.print_vehicle()
    if print_flag:
        print("printing...")
        g.print_file(print_file,False)

if __name__=="__main__":
    max_iter=30000000
    tabu_num=50000
    main(max_iter=max_iter,tabu_num=tabu_num,run=1,load=0,tabu=0)#get initial solution
    main(max_iter=max_iter,tabu_num=tabu_num,run=1,load=1,tabu=1)#tabu search