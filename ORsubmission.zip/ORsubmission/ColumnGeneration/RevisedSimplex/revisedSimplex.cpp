#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <ctime>
#include <cmath>
#include <iostream>
#include <vector>
#define Leefir
using namespace std;
#define rep(i, a, b) for(int i = a, i##_END_ = b; i < i##_END_; ++i)
#define per(i, a, b) for(int i = (b)-1, i##_BEGIN_ = a; i >= i##_BEGIN_; --i)
#ifdef Leefir
	#define ast(x) assert(x)
#else
	#define ast(x) ;
#endif
typedef double db;
typedef long long ll;

const int N = 25;
const db eps = 1e-9;
int n, m;
db c[N+N];
db a[N][N+N];
db b[N];
void input(){
	scanf("%d %d", &n, &m);
	//input data all integers!!!
	rep(i, 0, n) scanf("%lf", &c[i]);
	rep(i, n, n+m) c[i] = 0.0;
	rep(i, 0, m){
		rep(j, 0, n) scanf("%lf", &a[i][j]);
		rep(j, n, n+m) a[i][j] = (db)(j-n==i);
		scanf("%lf", &b[i]);
		ast(b[i] >= 0);
//bi >= 0
	}
}
void revisedSimplex(){
	static int bv[N], nbv[N];
	rep(i, 0, m) bv[i] = n+i;
	rep(i, 0, n) nbv[i] = i;
	static db Binv[N][N];
	rep(i, 0, m) rep(j, 0, m) Binv[i][j] = (db)(i==j);
	
	while(true){
		static db cbvBinv[N];//c_bv^T * Binv
		rep(i, 0, m){
			cbvBinv[i] = 0.0;
			rep(j, 0, m) cbvBinv[i] += c[bv[j]]*Binv[j][i];
		}
		static db price[N];
		rep(i, 0, n){
			price[i] = 0.0-c[nbv[i]];
			rep(j, 0, m) price[i] += cbvBinv[j]*a[j][nbv[i]];
		}
		//max problem. find minimum price
		//double mi = 1e30; int miID = -1;
		db mi = -eps; int miID = -1;
		rep(i, 0, n) if(price[i] < mi) mi = price[i], miID = i;
		if(miID == -1) break;
		//if(mi > eps) break;
		
		//nbv[miID] in bv
		int in = nbv[miID];
		static db column[N], rightHand[N];
		rep(i, 0, m){
			column[i] = 0.0;
			rep(j, 0, m) column[i] += Binv[i][j]*a[j][in];
			rightHand[i] = 0.0;
			rep(j, 0, m) rightHand[i] += Binv[i][j]*b[j];
			rep(j, 0, m) ast(rightHand[i] > -eps);
		}
		mi = 1e30; miID = -1;
		rep(i, 0, m){
			if(column[i] < eps) continue;
			db tmp = rightHand[i]/column[i];
			if(tmp < mi) mi = tmp, miID = i;
		}
		/*
		printf("mi %.9lf\n", mi);
		static int cnt = 0;
		if(++cnt > 100) break;
		*/
		if(miID == -1){
			puts("Unbounded");
			exit(0);
		}
		ast(miID != -1);
		//bv[miID] out bv
		//in becomes bv of rowmiID
		int out = bv[miID];
		rep(i, 0, m) if(i != miID){
			//if(-eps<=column[i] && column[i]<=eps) continue;
			rep(j, 0, m) Binv[i][j] += -Binv[miID][j]*column[i]/column[miID];
		}
		rep(i, 0, m) Binv[miID][i] /= column[miID];
		
		
		rep(i, 0, m) if(bv[i] == out) bv[i] = in;
		rep(i, 0, n) if(nbv[i] == in) nbv[i] = out;
		
	}
	db z = 0.0;
	static db cbvBinv[N];//c_bv^T * Binv
	rep(i, 0, m){
		cbvBinv[i] = 0.0;
		rep(j, 0, m) cbvBinv[i] += c[bv[j]]*Binv[j][i];
		z += cbvBinv[i]*b[i];
	}
	printf("%.10lf\n", z);
	static db x[N];
	rep(i, 0, n) x[i] = 0.0;
	static db rightHand[N];
	rep(i, 0, m){
		rightHand[i] = 0.0;
		rep(j, 0, m) rightHand[i] += Binv[i][j]*b[j];
		rep(j, 0, m) ast(rightHand[i] > -eps);
		if(bv[i] < n) x[bv[i]] = rightHand[i];
	}
	rep(i, 0, n) printf("%.10lf ", x[i]);
	putchar('\n');
}
int main(){
#ifdef Leefir
	freopen("data.in", "r", stdin);
#endif
	input();
	revisedSimplex();
	return 0;
}
