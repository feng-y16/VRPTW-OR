#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cassert>
#include <ctime>
#include <cmath>
#include <iostream>
#include <vector>
#include <algorithm>
#define Leefir
#define LocalDebug
using namespace std;
#define rep(i, a, b) for(int i = a, i##_END_ = b; i < i##_END_; ++i)
#define per(i, a, b) for(int i = (b)-1, i##_BEGIN_ = a; i >= i##_BEGIN_; --i)
#ifdef Leefir
	#define ast(x) assert(x)
	#define dig(...) fprintf(stderr, __VA_ARGS__)
#else
	#define ast(x) ;
	#define dig(...) ;
#endif

typedef double db;
typedef long long ll;
const db eps = 1e-9;
typedef pair<int, int> pii;
#define x first
#define y second
typedef vector<int> vi;
typedef vector<pii> vpii;
#define pb(x) push_back(x)
#define sz(x) (int)(x).size()


const int N = 115;
const int sumqMax = 220;
const int tMax = 1300;
const int maxRoutesAdded = 100;
const int maxDfsDepth = 20;
int n; // Vehicle Number
int capacity;
void digSeparator();
class Node{
	public:
		int id;
		int xCoord, yCoord;
		int demand, readyTime, dueTime, service;
		Node(){}
		void input(FILE *in);
		void output();
}node[N];
db costMatrix[N][N];
class Matrix;
class ColumnVector{
	private:
		//static const int N = 5;
		int sz;
		db arr[N];
	public:
		ColumnVector(){}
		ColumnVector(const int _sz){ sz = _sz;}
		db &operator[](const int x);
		ColumnVector operator*(Matrix &tmp) const;
		ColumnVector operator-(ColumnVector &tmp) const;
		db operator*(ColumnVector &tmp) const;
		void findMinimum(db &mi, int &miID);
		int getsz();
		void output();
};
class Matrix{
	private:
		//static const int N = 5;
		int r, c;
		db arr[N][N];
	public:
		Matrix(){}
		Matrix(const int _r, const int _c): r(_r), c(_c){}
		db *operator[](const int x);
		Matrix operator*(Matrix &tmp) const;
		ColumnVector operator*(ColumnVector &tmp) const;
		void eliminateForNewBV(const int rid, ColumnVector &column);
		Matrix getInverse();
		int getr();
		int getc();
		void readRow(const int rid);
		void output();
};
void outputRoutesVector(vector<vi> routes);
bool findColumn(ColumnVector &cbv, Matrix &invB, ColumnVector &initialColumn, vi &newRoute);
void columnGeneration(db LB, db UB, db cLB, Matrix &invB, ColumnVector &cbv, ColumnVector &b, vector<vi> &routes){
	int sz = n+3;
	//ColumnVector cbv(sz), b(sz);
	rep(i, 0, sz) cbv[i] = b[i] = 0.0;
	rep(i, 0, n) cbv[i] = (costMatrix[i][n]+costMatrix[n][i])*UB/(db)n;
	rep(i, 0, n) b[i] = 1.0;
	b[n] = LB; b[n+1] = cLB; b[n+2] = UB;
	
	Matrix B(sz, sz);
	rep(i, 0, sz) rep(j, 0, sz) B[i][j] = 0.0;
	rep(i, 0, n) B[i][i] = UB/(db)n;
	rep(i, 0, n) B[n][i] = 1.0; B[n][n] = -1.0;
	rep(i, 0, n) B[n+1][i] = cbv[i]; B[n+1][n+1] = -1.0;
	rep(i, 0, n) B[n+2][i] = 1.0; B[n+2][n+2] = 1.0;
	//Matrix invB = B.getInverse();
	invB = B.getInverse();
	
	//vector<vi> routes(sz);
	rep(i, 0, sz){
		vi vec(0); 
		if(i < n){ vec.pb(n); vec.pb(i); vec.pb(n);}
		routes[i] = vec;
	}
	
	while(true){
		//calculate reduced cost and find new column
		ColumnVector initialColumn(sz);
		vi newRoute(0);
		if(findColumn(cbv, invB, initialColumn, newRoute) == false) break;
		//calculate column in current tableu and righthand
		ColumnVector column = invB*initialColumn;
		ColumnVector rightHand = invB*b;
		//dig("reduced cost %.2lf\n", cbv*column-initialColumn[n+1]);
		ast(cbv*column-initialColumn[n+1] > eps);
		
		db mi = 1e30; int miID = -1;
		ast(column.getsz() == sz); ast(rightHand.getsz() == sz);
		//dig("rightHand\n");
		//rightHand.output();
		rep(i, 0, sz){
			//ast(rightHand[i] > -eps);
			if(column[i] < eps) continue;
			db tmp = rightHand[i]/column[i];
			if(tmp < mi) mi = tmp, miID = i;
		}
		ast(miID != -1); //else unbounded
		
		//update invB and cbv
		invB.eliminateForNewBV(miID, column);
		cbv[miID] = initialColumn[n+1]; //replace with c of new bv
		routes[miID] = newRoute;
		
	#ifdef LocalDebug
		//cbv.output();
		dig("curZ %.2lf\n", cbv*invB*b);
		outputRoutesVector(routes);
		ColumnVector LPsolution = invB*b;
		LPsolution.output();
		db vehicleSum = 0.0;
		cbv.output();
		rep(i, 0, sz) if(sz(routes[i])) vehicleSum += LPsolution[i];
		dig("vehicleSum %.2lf\n", vehicleSum);
	#endif
	}
}
bool forbiddenArc[N][N];
void getInverseTest();
void input(char str[]);

db currentBestZ; vector<vi> currentBestRoutes;
bool mark[N][N];
void branchAndBoundInit(){
	currentBestZ = 1e30; currentBestRoutes.clear();
	memset(forbiddenArc, false, sizeof forbiddenArc);
	memset(mark, false, sizeof mark);
}
bool isIntegerSolution(ColumnVector solution){
	rep(i, 0, n) if(ceil(solution[i]-eps)-solution[i]>eps) return false;
	return true;
}
int updateCount = 0;
char outputFileName[100];
void updateSolution(Matrix &invB, ColumnVector &cbv, ColumnVector &b, vector<vi> routes){
	db z = cbv*invB*b;
	if(z > currentBestZ) return;
	
	currentBestZ = z;
	currentBestRoutes.clear();
	ColumnVector solution = invB*b;
	rep(i, 0, n){
		db x = solution[i];
		if(x < eps) continue;
		ast(x > 1-eps);
		currentBestRoutes.pb(routes[i]);
	}
	FILE *out = fopen(outputFileName, "w");
	fprintf(out, "%.2lf\n", currentBestZ);
	rep(i, 0, sz(currentBestRoutes)){
		vi &route = currentBestRoutes[i];
		rep(j, 0, sz(route)){
			int x = route[j];
			if(x == n) x = 0; else ++x;
			fprintf(out, "%d ", x);
		}
		fprintf(out, "\n");
	}
	fclose(out);
	
	digSeparator();
	++updateCount;
	dig("uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuupdate solution\n");
	dig("z %.2lf\n", z);
	outputRoutesVector(currentBestRoutes);
}
inline db min(db x, db y){
	if(x < y) return x;
	return y;
}
void branchAndBoundDfs(int depth, db LB, db UB, db cLB, Matrix &invB, ColumnVector &cbv, ColumnVector &b, vector<vi> routes){
	dig("________________________________________________________________________________________________");
	dig("depth %d [%.2lf, %.2lf] cLB %.2lf updateCount %d\n", depth, LB, UB, cLB, updateCount);
	if(depth > maxDfsDepth) return;
	
	rep(i, 0, n+1) ast(forbiddenArc[i][n]==false && forbiddenArc[n][i]==false);
//	if(forbiddenArc[i][n] || forbiddenArc[n][i]) return;
	columnGeneration(LB, UB, cLB, invB, cbv, b, routes);

	db z = cbv*invB*b;
	if(z > currentBestZ) return;
	ColumnVector LPsolution = invB*b;
	dig("z %.2lf\n", z);
	LPsolution.output();
	if(isIntegerSolution(LPsolution)){
		updateSolution(invB, cbv, b, routes);
		return;
	}
		
	db ceilZ10 = ceil(z*10.0-eps);
	if(ceilZ10-z*10.0 > 1e-5){
		branchAndBoundDfs(depth+1, LB, UB, ceilZ10/10.0-eps, invB, cbv, b, routes);
		return;
	}
	
	db vehicleSum = 0.0;
	rep(i, 0, n+3) if(sz(routes[i])) vehicleSum += LPsolution[i];
	db ceilVehicleSum = ceil(vehicleSum-eps);
	dig("vehicleSum %.2lf ceilVehicleSum %.2lf\n", vehicleSum, ceilVehicleSum);
	if(ceilVehicleSum-vehicleSum > 1e-5){
		branchAndBoundDfs(depth+1, ceilVehicleSum-eps, UB, cLB, invB, cbv, b, routes);
		branchAndBoundDfs(depth+1, LB, ceilVehicleSum-1.0+eps, cLB, invB, cbv, b, routes);
		return;
	}
	
	static db score[N][N];
	rep(i, 0, n+1) rep(j, 0, n+1) score[i][j] = 0.0;
	rep(i, 0, sz(routes)){
		rep(j, 0, sz(routes[i])-1){
			int u = routes[i][j], v = routes[i][j+1];
			if(u == n || v == n) continue;
			ast(forbiddenArc[u][v] == false);
			if(mark[u][v]) continue;
			db tmp = costMatrix[u][v] * min(LPsolution[i], 1.0-LPsolution[i]);
			score[u][v] += tmp;
		}
	}
	db mx = -1e30; int mxu = -1, mxv = -1;
	rep(i, 1, n) rep(j, 1, n) if(score[i][j] > mx)
		mx = score[i][j], mxu = i, mxv = j;
	ast(mxu != -1 && mxv != -1);
	
	
	mark[mxu][mxv] = true;
	
	dig("(%d, %d) 1\n", mxu, mxv);
	bool mem[N]; memcpy(mem, forbiddenArc[mxu], sizeof mem);
	rep(i, 0, n) if(i != mxv) forbiddenArc[mxu][i] = true;
	branchAndBoundDfs(depth+1, LB, UB, cLB, invB, cbv, b, routes);
	memcpy(forbiddenArc[mxu], mem, sizeof mem);
	
	dig("(%d, %d) 0\n", mxu, mxv);
	forbiddenArc[mxu][mxv] = true;
	branchAndBoundDfs(depth+1, LB, UB, cLB, invB, cbv, b, routes);
	forbiddenArc[mxu][mxv] = false;
	
	mark[mxu][mxv] = false;
}
void branchAndBound(){
	int sz = n+3;
	ColumnVector cbv(sz), b(sz);
	Matrix invB(sz, sz);
	vector<vi> routes(sz);
	
	branchAndBoundDfs(0, 0.0-eps, (db)n+eps, 0.0-eps, invB, cbv, b, routes);
	dig("updateCount %d\n", updateCount);
}
int main(int argc, char **args){
#ifdef Leefir
	srand(time(NULL));
	dig("DLeefir\n");
#endif
#ifdef LocalDebug
	dig("DLocalDebug\n");
	dig("N %d\n", N);
	dig("sumqMax %d\n", sumqMax);
	dig("tMax %d\n", tMax);
	dig("N*sumqMax*tMax*3 %.2lf\n", (db)N*sumqMax*tMax*3.0);
#endif
	//char str[] = "data.in";
	//input(str);
	char *p = args[1], *q = outputFileName;
	while(*p) *q = *p, ++q, ++p;
	if(args[2][0] == '2'){ ast(args[2][1] == '5'); n = 25; *q = '1'; ++q;}
	if(args[2][0] == '5'){ ast(args[2][1] == '0'); n = 50; *q = '2'; ++q;}
	if(args[2][0] == '1'){ ast(args[2][1] == '0'); n = 100; *q = '3'; ++q;}
	/*
	*q = '.'; ++q;
	*q = 'o'; ++q;
	*q = 'u'; ++q;
	*q = 't'; ++q;
	*/
	*q = 0; ++q;
	puts(outputFileName);
	
	input(args[1]);	
	branchAndBoundInit();
	branchAndBound();
	//columnGeneration(5.0-eps, (db)n);
	printf("%.2lf", clock()/(db)CLOCKS_PER_SEC);
	return 0;
}
/////////////////////////////////////////////
inline void digSeparator(){
	dig("______________________________________\n");
}
inline void swap(db &x, db &y){
	db t = x; x = y; y = t;
}
inline db fabs(db x){
	if(x < 0) return -x;
	return x;
}
//class ColumnVector
db &ColumnVector::operator[](const int x){
	return arr[x];
}
void ColumnVector::output(){
	digSeparator();
	rep(i, 0, sz) printf("%.2lf%c", arr[i], " \n"[i==sz-1]);
}
ColumnVector ColumnVector::operator*(Matrix &tmp) const{
	//transpostion * tmp
	ast(sz == tmp.getr());
	int c = tmp.getc();
	ColumnVector res(c);
	rep(i, 0, c){
		res[i] = 0.0;
		rep(j, 0, sz) res[i] += arr[j]*tmp[j][i];
	}
	return res;
}
ColumnVector ColumnVector::operator-(ColumnVector &tmp) const{
	ast(sz == tmp.getsz());
	ColumnVector res(sz);
	rep(i, 0, sz) res[i] = arr[i]-tmp[i];
	return res;
}
db ColumnVector::operator*(ColumnVector &tmp) const{
	db res = 0.0;
	ast(sz == tmp.getsz());
	rep(i, 0, sz) res += arr[i]*tmp[i];
	return res;
}
void ColumnVector::findMinimum(db &mi, int &miID){
	rep(i, 0, sz) if(arr[i] < mi)
		mi = arr[i], miID = i;
}
int ColumnVector::getsz(){ return sz;}
//class Matrix
db *Matrix::operator[](const int x){
	return arr[x];
}
Matrix Matrix::operator*(Matrix &tmp) const{
	ast(c == tmp.getr());
	int _c = tmp.getc();
	Matrix res(r, _c);
	rep(i, 0, r) rep(j, 0, _c){
		res[i][j] = 0.0;
		rep(k, 0, c) res[i][j] += arr[i][k] * tmp[k][j];
	}
	return res;
}
ColumnVector Matrix::operator*(ColumnVector &tmp) const{
	ast(c == tmp.getsz());
	ColumnVector res(r);
	rep(i, 0, r){
		res[i] = 0;
		rep(j, 0, c) res[i] += arr[i][j]*tmp[j];
	}
	return res;
}
void Matrix::eliminateForNewBV(const int rid, ColumnVector &column){
	rep(i, 0, r) if(i != rid){
		rep(j, 0, c) arr[i][j] += -column[i]*arr[rid][j]/column[rid]; //for precision
		//(-column[i]/column[rid])*arr[rid][j];
	}
	rep(i, 0, c) arr[rid][i] /= column[rid];
}
void outputArray(int n, db arr[N][N]){
	digSeparator();
	rep(i, 0, n) rep(j, 0, n) printf("%.2lf%c", arr[i][j], " \n"[j==n-1]);
}
Matrix Matrix::getInverse(){
	ast(r == c);
	static db tmp[N][N], inv[N][N];
	rep(i, 0, r) rep(j, 0, c) inv[i][j] = (db)(i==j);
	rep(i, 0, r) rep(j, 0, c) tmp[i][j] = arr[i][j];
	rep(i, 0, r){
		db mx = -1e30; int mxID = -1;
		rep(j, i, r) if(fabs(tmp[j][i]) > mx) mx = fabs(tmp[j][i]), mxID = j;
		ast(mxID != -1);
		rep(j, 0, c) swap(tmp[mxID][j], tmp[i][j]), swap(inv[mxID][j], inv[i][j]);
		rep(j, i+1, r){
			db mem = tmp[j][i];
			rep(k, 0, c){
				tmp[j][k] += -mem*tmp[i][k]/tmp[i][i];
				inv[j][k] += -mem*inv[i][k]/tmp[i][i];
				//-tmp[j][i]/tmp[i][i]*tmp[i][k];
			}
		}
		//outputArray(r, tmp);
		//outputArray(r, inv);
	}
	//eliminate		
	per(i, 0, r){
		rep(j, 0, i){
			if(fabs(tmp[j][i]) < eps) continue;
			db mem = tmp[j][i];
			rep(k, 0, c){
				tmp[j][k] += -mem*tmp[i][k]/tmp[i][i];
				inv[j][k] += -mem*inv[i][k]/tmp[i][i];
			}
			//-tmp[j][i]/tmp[i][i]*tmp[i][k];
		}
		db mem = tmp[i][i];
		rep(j, 0, c) tmp[i][j] /= mem, inv[i][j] /= mem;
		//outputArray(r, tmp);
		//outputArray(r, inv);
	}
	Matrix res(r, c);
	rep(i, 0, r) rep(j, 0, c) res[i][j] = inv[i][j];
	return res;
}
int Matrix::getc(){ return c;}
int Matrix::getr(){ return r;}
void Matrix::readRow(const int rid){
	rep(i, 0, c) scanf("%lf", &arr[rid][i]);
}
void Matrix::output(){
	digSeparator();
	rep(i, 0, r) rep(j, 0, c) printf("%.2lf%c", arr[i][j], " \n"[j==c-1]);
}
////////////////////////////////////
void outputRoutesVector(vector<vi> routes){
	digSeparator();
	dig("routes\n");
	rep(i, 0, sz(routes)){
		rep(j, 0, sz(routes[i])) dig("%d ", routes[i][j]);
		dig("\n");
	}
}
db dpCostMatrix[N][N];
db G[N][sumqMax][tMax];
int pre[N][sumqMax][tMax][3];
inline bool chkmin(int &x, int y){
	if(x > y){ x = y; return true;}
	return false;
}
inline bool chkmax(int &x, int y){
	if(x < y){ x = y; return true;}
	return false;
}
inline bool chkmin(db &x, db y){
	if(x > y){ x = y; return true;}
	return false;
}
inline bool chkmax(db &x, db y){
	if(x < y){ x = y; return true;}
	return false;
}
db dpWork(ColumnVector &initialColumn, vi &newRoute){
	int sumq = capacity; ast(sumq < sumqMax);
	int tmax = 0; rep(i, 0, n+1) chkmax(tmax, node[i].dueTime); ast(tmax < tMax);
	rep(i, 0, n+1) rep(j, 0, sumq+1) rep(k, node[i].readyTime, node[i].dueTime+1)
		G[i][j][k] = 1e30, pre[i][j][k][0] = pre[i][j][k][1] = pre[i][j][k][2] = -1;


	G[n][0][0] = 0;
	rep(q, 0, sumq+1){
		rep(j, 0, n+1) rep(t, node[j].readyTime, node[j].dueTime+1) {
			rep(i, 0, n+1) if(i!=j){
				if(node[i].readyTime+costMatrix[i][j]+node[i].service+eps > t) continue;
				//if(dpCostMatrix[i][j] > 1e9) continue;
				int q_ = q-node[j].demand; if(q_ < 0) continue;
				int t_ = min(node[i].dueTime, t-(int)ceil(costMatrix[i][j])-node[i].service);
				//if(t_ < 0) continue;
				if(t_ < node[i].readyTime) continue;
				if(chkmin(G[j][q][t], G[i][q_][t_]+dpCostMatrix[i][j]))
					pre[j][q][t][0] = i, pre[j][q][t][1] = q_, pre[j][q][t][2] = t_;
			}
			if(t != node[j].readyTime) if(chkmin(G[j][q][t], G[j][q][t-1]))
				memcpy(pre[j][q][t], pre[j][q][t-1], sizeof pre[j][q][t]);
		}
		if(q != 0) rep(j, 0, n+1) rep(t, node[j].readyTime, node[j].dueTime+1)
			if(chkmin(G[j][q][t], G[j][q-1][t]))
				memcpy(pre[j][q][t], pre[j][q-1][t], sizeof pre[j][q][t]);
	}
	
	
	/*
	int wq = -1, wt = -1; db mi = 1e30;
	rep(q, 0, sumq+1) rep(t, 0, tmax+1)
		if(mi > G[n][q][t]) mi = G[n][q][t], wq = q, wt = t;
	*/
	int wq = sumq, wt = node[n].dueTime; db mi = G[n][wq][wt];
	int cur = n;
#ifdef LocalDebug
	dig("mi %.2lf\n", mi);
#endif
	db routeDistanceCost = 0.0;
	newRoute.clear(); newRoute.pb(cur); ast(cur == n);
	while(true){
		ast(wq >= 0); ast(wt >= 0);
		if(pre[cur][wq][wt][0] == -1) break;
		//dig("%d %d %d   %d\n", cur, wq, wt, pre[cur][wq][wt][0]);
		int *tmp = pre[cur][wq][wt];
		routeDistanceCost += costMatrix[tmp[0]][cur];
		//if(initialColumn[cur] < eps) initialColumn[cur] = 1.0;
		initialColumn[cur] += 1.0;
		cur = tmp[0]; wq = tmp[1]; wt = tmp[2];
		newRoute.pb(cur);
	}
	ast(cur == n);
	reverse(newRoute.begin(), newRoute.end());
	initialColumn[n] = 1.0;
	initialColumn[n+1] = routeDistanceCost;
	initialColumn[n+2] = 1.0;
	return mi;
}
bool findColumn(ColumnVector &cbv, Matrix &invB, ColumnVector &initialColumn, vi &newRoute){
	ColumnVector dual = cbv*invB;
	rep(i, 0, n+1) rep(j, 0, n+1){
		if(forbiddenArc[i][j]) dpCostMatrix[i][j] = 1e10;
		else dpCostMatrix[i][j] = (1.0-dual[n+1])*costMatrix[i][j]-(i<n?dual[i]:0.0);
	}
	rep(i, 0, n+3) initialColumn[i] = 0.0;
	db tmp = dpWork(initialColumn, newRoute)-dual[n]+dual[n+2];
	//dig("dp result %.2lf dual[n] %.2lf dual[n+2] %.2lf\n", tmp, dual[n], dual[n+2]);
	if(tmp < -eps) return true;
	return false;
}
void getInverseTest(){
	while(true){
		int n;
		scanf("%d", &n);
		Matrix A(n, n);
		rep(i, 0, n) rep(j, 0, n) scanf("%lf", &A[i][j]);
		Matrix invA = A.getInverse();
		A.output();
		invA.output();
	}
}

//////////////////////////////////////////
//Node
void Node::input(FILE *in){
	fscanf(in, "%d %d %d %d %d %d %d", &id, &xCoord, &yCoord, &demand, &readyTime, &dueTime, &service);
}
void Node::output(){
	printf("%d %d %d %d %d %d %d\n", id, xCoord, yCoord, demand, readyTime, dueTime, service);
}

//////////////////////////////////////////
#define pow2(x) (x)*(x)
db calculateDistance(Node &a, Node &b){
	return floor(10.0*sqrt(pow2(a.xCoord-b.xCoord) + pow2(a.yCoord-b.yCoord)))/10.0;
}
void input(char str[]){
	FILE *in = fopen(str, "r");
	static char tmp[10000];
	rep(i, 0, 9) fgets(tmp, 10000, in);
	capacity = 200;
//	fscanf(in, "%d %d", &n, &capacity);
	node[n].input(in);
	rep(i, 0, n) node[i].input(in);
	fclose(in);
	
	rep(i, 0, n+1) rep(j, 0, n+1) costMatrix[i][j] = calculateDistance(node[i], node[j]);
}


