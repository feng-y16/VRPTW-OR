#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cassert>
#include <ctime>
#include <cmath>
#include <iostream>
#include <vector>
#define Leefir
#define LocalDebug
using namespace std;
#define rep(i, a, b) for(int i = a, i##_END_ = b; i < i##_END_; ++i)
#define per(i, a, b) for(int i = (b)-1, i##_BEGIN_ = a; i >= i##_BEGIN_; --i)
#ifdef Leefir
	#define ast(x) assert(x)
#else
	#define ast(x) ;
#endif

typedef double db;
typedef long long ll;
const db eps = 1e-9;

const int N = 20;
const int maxRollWidth = 10000;
class Matrix;
class ColumnVector{
	private:
		//static const int N = 5;
		int sz;
		db arr[N];
	public:
		ColumnVector(){}
		ColumnVector(const int _sz): sz(_sz){}
		db &operator[](const int x);
		ColumnVector operator*(Matrix &tmp) const;
		ColumnVector operator-(ColumnVector &tmp) const;
		db operator*(ColumnVector &tmp) const;
		void findMinimum(db &mi, int &miID);
		int getsz();
		void output();
};
class Matrix{
	private:
		//static const int N = 5;
		int r, c;
		db arr[N][N];
	public:
		Matrix(){}
		Matrix(const int _r, const int _c): r(_r), c(_c){}
		db *operator[](const int x);
		Matrix operator*(Matrix &tmp) const;
		ColumnVector operator*(ColumnVector &tmp) const;
		void eliminateForNewBV(const int rid, ColumnVector &column);
		Matrix getInverse();
		int getr();
		int getc();
		void readRow(const int rid);
		void output();
};

int rollWidth;
int n;
int demandedWidth[N];
int demandedAmount[N];
/*
void input(){
	scanf("%d", &rollWidth);
	n = 13;
	rep(i, 0, n) scanf("%d", &demandedWidth[i]);
	rep(i, 0, n) scanf("%d", &demandedAmount[i]);
	//scanf("[%lf,%lf,%lf]", &demandedWidth[0], &demandedWidth[1], &demandedWidth[2]);
	//scanf("[%lf,%lf,%lf]", &demandedAmount[0], &demandedAmount[1], &demandedAmount[2]);
	
}
*/
void input(){
	fscanf(stdin, "%d", &rollWidth);
	char c; while(fscanf(stdin, "%c", &c), c!='[');
	int p = 0; while(fscanf(stdin, "%d%c", &demandedWidth[p++], &c), c!=']');
	n = p;
	while(fscanf(stdin, "%c", &c), c!='[');
	p = 0; while(fscanf(stdin, "%d%c", &demandedAmount[p++], &c), c!=']');
	ast(n == p);
}
bool findColumn(ColumnVector &cbv, Matrix &invB, ColumnVector &initialColumn);
void columnGeneration(){
//initialize invB, cbv and b
	Matrix invB(n, n);
	ColumnVector cbv(n), b(n);
	rep(i, 0, n) rep(j, 0, n) invB[i][j] = 0.0;
	rep(i, 0, n) invB[i][i] = 1.0/(rollWidth/demandedWidth[i]); //17/3=5 17/5=3 17/9=1
	rep(i, 0, n) cbv[i] = 1.0; //always 1 in cutting stock problem
	rep(i, 0, n) b[i] = demandedAmount[i];
//column generation
	while(true){
	#ifdef LocalDebug
		invB.output();
		//static int cnt = 0;
		//if(++cnt > 3) break;
	#endif
		//calculate reduced cost and find new column
		ColumnVector initialColumn(n);
		if(findColumn(cbv, invB, initialColumn) == false) break;
		
		//calculate column in current tableu and righthand
		ColumnVector column = invB*initialColumn;
		ColumnVector rightHand = invB*b;
		
		//minimum ratio test
		db mi = 1e30; int miID = -1;
		ast(column.getsz() == n); ast(rightHand.getsz() == n);
		rep(i, 0, n){
			ast(rightHand[i] > -eps);
			if(column[i] < eps) continue;
			db tmp = rightHand[i]/column[i];
			if(tmp < mi) mi = tmp, miID = i;
		}
		ast(miID != -1); //else unbounded
		
		//update invB and cbv
		invB.eliminateForNewBV(miID, column);
		cbv[miID] = 1.0; //replace with c of new bv
		//break;
	}
//output
	db z = cbv*invB*b; //cbvT*invB*b
	//printf("%.2lf\n", z); 
	int ceillingZ = (int)(z+1.0-eps);
	printf("%d\n", ceillingZ);
	invB.getInverse().output();
	(invB*b).output(); //rightHand
	//get ceiling of each bv
}
void getInverseTest();
int main(){
#ifdef Leefir
	srand(time(NULL));
	fprintf(stderr, "DLeefir\n");
#endif
#ifdef LocalDebug
	fprintf(stderr, "DLocalDebug\n");
	//getInverseTest();
#endif
	freopen("data.in", "r", stdin);
	input();
	columnGeneration();
	return 0;
}
/////////////////////////////////////////////
inline void printSeparator(){
	puts("______________________________");
}
inline void swap(db &x, db &y){
	db t = x; x = y; y = t;
}
inline db fabs(db x){
	if(x < 0) return -x;
	return x;
}
//class ColumnVector
db &ColumnVector::operator[](const int x){
	return arr[x];
}
void ColumnVector::output(){
	printSeparator();
	rep(i, 0, sz) printf("%.2lf%c", arr[i], " \n"[i==sz-1]);
}
ColumnVector ColumnVector::operator*(Matrix &tmp) const{
	//transpostion * tmp
	ast(sz == tmp.getr());
	int c = tmp.getc();
	ColumnVector res(c);
	rep(i, 0, c){
		res[i] = 0.0;
		rep(j, 0, sz) res[i] += arr[j]*tmp[j][i];
	}
	return res;
}
ColumnVector ColumnVector::operator-(ColumnVector &tmp) const{
	ast(sz == tmp.getsz());
	ColumnVector res(sz);
	rep(i, 0, sz) res[i] = arr[i]-tmp[i];
	return res;
}
db ColumnVector::operator*(ColumnVector &tmp) const{
	db res = 0.0;
	ast(sz == tmp.getsz());
	rep(i, 0, sz) res += arr[i]*tmp[i];
	return res;
}
void ColumnVector::findMinimum(db &mi, int &miID){
	rep(i, 0, sz) if(arr[i] < mi)
		mi = arr[i], miID = i;
}
int ColumnVector::getsz(){ return sz;}
//class Matrix
db *Matrix::operator[](const int x){
	return arr[x];
}
Matrix Matrix::operator*(Matrix &tmp) const{
	ast(c == tmp.getr());
	int _c = tmp.getc();
	Matrix res(r, _c);
	rep(i, 0, r) rep(j, 0, _c){
		res[i][j] = 0.0;
		rep(k, 0, c) res[i][j] += arr[i][k] * tmp[k][j];
	}
	return res;
}
ColumnVector Matrix::operator*(ColumnVector &tmp) const{
	ast(c == tmp.getsz());
	ColumnVector res(r);
	rep(i, 0, r){
		res[i] = 0;
		rep(j, 0, c) res[i] += arr[i][j]*tmp[j];
	}
	return res;
}
void Matrix::eliminateForNewBV(const int rid, ColumnVector &column){
	rep(i, 0, r) if(i != rid){
		rep(j, 0, c) arr[i][j] += -column[i]*arr[rid][j]/column[rid]; //for precision
		//(-column[i]/column[rid])*arr[rid][j];
	}
	rep(i, 0, c) arr[rid][i] /= column[rid];
}
void outputArray(int n, db arr[N][N]){
	printSeparator();
	rep(i, 0, n) rep(j, 0, n) printf("%.2lf%c", arr[i][j], " \n"[j==n-1]);
}
Matrix Matrix::getInverse(){
	ast(r == c);
	static db tmp[N][N], inv[N][N];
	rep(i, 0, r) rep(j, 0, c) inv[i][j] = (db)(i==j);
	rep(i, 0, r) rep(j, 0, c) tmp[i][j] = arr[i][j];
	rep(i, 0, r){
		db mx = -1e30; int mxID = -1;
		rep(j, i, r) if(fabs(tmp[j][i]) > mx) mx = fabs(tmp[j][i]), mxID = j;
		ast(mxID != -1);
		rep(j, 0, c) swap(tmp[mxID][j], tmp[i][j]), swap(inv[mxID][j], inv[i][j]);
		rep(j, i+1, r){
			db mem = tmp[j][i];
			rep(k, 0, c){
				tmp[j][k] += -mem*tmp[i][k]/tmp[i][i];
				inv[j][k] += -mem*inv[i][k]/tmp[i][i];
				//-tmp[j][i]/tmp[i][i]*tmp[i][k];
			}
		}
		//outputArray(r, tmp);
		//outputArray(r, inv);
	}
	//eliminate		
	per(i, 0, r){
		rep(j, 0, i){
			if(fabs(tmp[j][i]) < eps) continue;
			db mem = tmp[j][i];
			rep(k, 0, c){
				tmp[j][k] += -mem*tmp[i][k]/tmp[i][i];
				inv[j][k] += -mem*inv[i][k]/tmp[i][i];
			}
			//-tmp[j][i]/tmp[i][i]*tmp[i][k];
		}
		db mem = tmp[i][i];
		rep(j, 0, c) tmp[i][j] /= mem, inv[i][j] /= mem;
		//outputArray(r, tmp);
		//outputArray(r, inv);
	}
	Matrix res(r, c);
	rep(i, 0, r) rep(j, 0, c) res[i][j] = inv[i][j];
	return res;
}
int Matrix::getc(){ return c;}
int Matrix::getr(){ return r;}
void Matrix::readRow(const int rid){
	rep(i, 0, c) scanf("%lf", &arr[rid][i]);
}
void Matrix::output(){
	printSeparator();
	rep(i, 0, r) rep(j, 0, c) printf("%.2lf%c", arr[i][j], " \n"[j==c-1]);
}
////////////////////////////////////
bool findColumn(ColumnVector &cbv, Matrix &invB, ColumnVector &initialColumn){
	//const cbv and invB !!!
	//cnbv = (1, 1, 1, ...) omitted
	//maximize cbvT*invB*column
	ColumnVector value = cbv*invB;//cbvT*invB
	static int weight[N];
	rep(i, 0, n) weight[i] = demandedWidth[i];
	//value double; weight int
	

	static db dp[maxRollWidth];
	static int preWeight[maxRollWidth], pre[maxRollWidth];
	ast(rollWidth < maxRollWidth);
	int maxWeight = rollWidth;
	rep(i, 0, maxWeight+1) dp[i] = -1e30, pre[i] = -1;
	dp[0] = 0.0;
	rep(i, 0, n) rep(j, 0, maxWeight-weight[i]+1){
		db tmp = dp[j]+value[i];
		int to = j+weight[i];
		if(dp[to] < tmp){
			dp[to] = tmp;
			pre[to] = i;
			preWeight[to] = j;
		}
	}
	db mx = eps; int mxID = -1;
	//db mx = -eps; int mxID = -1;
	rep(i, 0, maxWeight+1) if(mx < dp[i]-1.0) mx = dp[i]-1.0, mxID = i;
	if(mxID == -1) return false;
	rep(i, 0, n) initialColumn[i] = 0.0;
	int cur = mxID;
	while(true){
		ast(cur >= 0);
		if(pre[cur] == -1){ ast(cur == 0); break;}
		initialColumn[pre[cur]] += 1.0;
		cur = preWeight[cur];
	}
	#ifdef LocalDebug
		//printf("dp[%d] %.2lf\n", mxID, mx);
	#endif
	return true;
}
void getInverseTest(){
	while(true){
		int n;
		scanf("%d", &n);
		Matrix A(n, n);
		rep(i, 0, n) rep(j, 0, n) scanf("%lf", &A[i][j]);
		Matrix invA = A.getInverse();
		A.output();
		invA.output();
	}
}
