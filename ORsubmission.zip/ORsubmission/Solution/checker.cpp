#include <cstdio>
#include <cstring>
#include <cassert>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <iostream>
#include <vector>
#define Leefir
#define LocalDebug
using namespace std;
#define rep(i, a, b) for(int i = a, i##_END_ = b; i < i##_END_; ++i)
#define per(i, a, b) for(int i = (b)-1, i##_BEGIN_ = a; i >= i##_BEGIN_; --i)
#ifdef Leefir
	#define ast(x) assert(x)
	#define dig(...) fprintf(stderr, __VA_ARGS__)
#else
	#define ast(x) ;
	#define dig(...) ;
#endif
typedef double db;
typedef long long ll;
const db eps = 1e-9;
typedef vector<int> vi;
typedef pair<int, int> pii;
#define pb(x) push_back(x)
#define sz(x) (int)(x).size()

const int LineLengthMax = 10000;
const int VehicleAmountMax = 1000;
const int EdgeSize = 1211100;
const int NodeSize = 1101;
bool readNonnegativeInt(char *&str, int &x);
void printSeparator();
class Edge{
	public:
		Edge(){}
		int edgeID;
		int from, to;
		int dis, tm;
		void input(FILE *in);
		void output();
}edge[EdgeSize+5];
int disMatrix[NodeSize+5][NodeSize+5];
int tmMatrix[NodeSize+5][NodeSize+5];
class Node{
	public:
		Node(){}
		int nodeID;
		int nodeType;
		db longitude, latitude;
		db weight, volume;
		int L, R;
		void input(FILE *in);
		void output();
}node[NodeSize+5];
class VehiclePath{
	public:
		int vehicleType;
		vi path;
		VehiclePath(){}
		void read(char *str);
		void output();
}vp[VehicleAmountMax];
class VehicleInfo{
	public:
		VehicleInfo(){}
		int typeID;
		db maxVolume, maxWeight;
		int  drivingRange, chargeTime;
		int unitTransCost, vehicleCost;
		void init(int _typeID, db _maxVolume, db _maxWeight, int _drivingRange, int _chargeTime, int _unitTransCost, int _vehicleCost);
		void output();
}vehicleInfo[3]; //0 omitted
int n;
void init();
void input(char*);
void examineValidity();
int main(int argc, char **args){
#ifdef Leefir
	srand(time(NULL));
	dig("DLeefir\n");
#endif
#ifdef LocalDebug
	dig("DLocalDebug\n");
#endif
	init();
	dig("%d %d\n", disMatrix[0][4], tmMatrix[0][4]);
	//vehicleInfo[1].output(); vehicleInfo[2].output();
	input(args[1]);	
	examineValidity();
	return 0;
}
void init(){
	//0 omitted
	vehicleInfo[1].init(
	1, 12.0, 2.0, 100000, 30, 12, 200);
	vehicleInfo[2].init(
	2, 16.0, 2.5, 120000, 30, 14, 300);
	//vehicleInfo[1].output(); vehicleInfo[2].output();
	
	FILE *edgeFile = fopen("input_distance-time.dat", "r");
	rep(i, 0, EdgeSize){
		edge[i].input(edgeFile);
		disMatrix[edge[i].from][edge[i].to] = edge[i].dis;
		tmMatrix[edge[i].from][edge[i].to] = edge[i].tm;
	}
	fclose(edgeFile);
	//rep(i, 0, EdgeSize) edge[i].output();
	
	
	FILE *nodeFile = fopen("input_node.dat", "r");
	rep(i, 0, NodeSize) node[i].input(nodeFile);
	fclose(nodeFile);
	//rep(i, 0, NodeSize) node[i].output();
}
void input(char *FileName){
	FILE *in = fopen(FileName, "r");
	static char str[LineLengthMax];
	n = 0;
	while(fgets(str, LineLengthMax, in) != NULL) vp[n++].read(str);
	fclose(in);
	//rep(i, 0, n) vp[i].output();
}
void examineValidity(){
	//time windows
	//full service
	static bool vis[NodeSize+5];
	memset(vis, false, sizeof vis);
	int waitingTime = 0; //minute
	int chargingCount = 0; //times
	db totalCost = 0.0;
	static const int waitingInDepot = 60;
	static const int unloadingTime = 30;
	static const int chargingTime = 30;
	db totalDrivingDistance = 0.0;
	rep(i, 0, n){
	#ifdef LocalDebug
		dig("%d\n", i);
	#endif
		VehiclePath &now = vp[i];
		VehicleInfo &info = vehicleInfo[now.vehicleType];
		vi &path = now.path;
		int remainingRange = info.drivingRange;
		db drivingDistance = 0.0;
		db accumulatedWeight = 0.0, accumulatedVolume = 0.0;
		int currentTime = 8*60;
		int singleChargingCount = 0;
		int singleWaitingTime = 0;
		rep(j, 0, sz(path)-1){
			int u = path[j], v = path[j+1];
		#ifdef LocalDebug
			dig("%d -> %d  dis %d tm %d\n", u, v, disMatrix[u][v], tmMatrix[u][v]);
		#endif
		/*
			if(j == 0){
				ast(node[v].nodeType == 2);
				int L = node[v].L, R = node[v].R;
				if(currentTime+tmMatrix[u][v] < L) currentTime = L-tmMatrix[u][v];
			}
		*/
			drivingDistance += disMatrix[u][v];
			remainingRange -= disMatrix[u][v];
			currentTime += tmMatrix[u][v];
		#ifdef LocalDebug
			dig("dis %d remainingRange %d currentTime %d\n", disMatrix[u][v], remainingRange, currentTime);
		#endif
			ast(remainingRange >= 0);
			if(node[v].nodeType == 1){
				ast(v == 0);
				if(u == 0) continue;
				ast(currentTime <= node[v].R);
				if(j != sz(path)-2){
					waitingTime += waitingInDepot;
					singleWaitingTime += waitingInDepot;
					currentTime += waitingInDepot;
					remainingRange = info.drivingRange;
				}
				accumulatedWeight = 0.0;
				accumulatedVolume = 0.0;
			}else if(node[v].nodeType == 2){
				ast(vis[v] == false);
				vis[v] = true;
				int L = node[v].L, R = node[v].R;
				if(j == 0){
					if(currentTime < L) currentTime = L;
				}
				ast(currentTime <= R);
				dig("%d currentTime %d [%d, %d]\n", v, currentTime, L, R);
				if(currentTime < L){
					waitingTime += L-currentTime;
					singleWaitingTime += L-currentTime;
					currentTime = L;
				}
				currentTime += unloadingTime;
				//printf("currentTime %d singleWaitingTime %d\n", currentTime, singleWaitingTime);
				accumulatedWeight += node[v].weight;
				accumulatedVolume += node[v].volume;
				ast(accumulatedWeight < info.maxWeight+eps);
				ast(accumulatedVolume < info.maxVolume+eps);
			}else if(node[v].nodeType == 3){
				currentTime += chargingTime;
				chargingCount++;
				singleChargingCount++;
				remainingRange = info.drivingRange;
			}else ast(false);
		}
		totalCost += drivingDistance*info.unitTransCost/1000.0;
		totalCost += info.vehicleCost;
		totalDrivingDistance += drivingDistance;
//		printf("%.2lf %.2lf %d\n", drivingDistance, totalCost, info.unitTransCost);
		db singleCost = drivingDistance*info.unitTransCost/1000.0+info.vehicleCost+singleChargingCount*50.0+singleWaitingTime*24.0/60.0;
		printf("%.2lf singleChargingCount %d singleWaitingTime %d\n", singleCost, singleChargingCount, singleWaitingTime);
		//now.output();	
	}
	rep(i, 0, NodeSize) if(node[i].nodeType == 2) ast(vis[i]==true);
	printf("vehicleCost+drvingCost %.2lf\n", totalCost);
	totalCost += chargingCount*50.0 + waitingTime*24.0/60.0;
	printf("chargingCount %d chargingCost %.2lf\n", chargingCount, chargingCount*50.0);
	printf("waitingTime(minutes) %d waitingCost %.2lf\n", waitingTime, waitingTime*24.0/60.0);
	printf("totalDrivingDistance %.2lf\n", totalDrivingDistance);
	printf("totalCost %.2lf\n", totalCost);
}
//////////////////////////////////////////////////
void printSeparator(){
	puts("____________________________________");
}	
bool readNonnegativeInt(char *&str, int &x){
	//*str changed
	x = 0;
	while(!(*str>='0'&&*str<='9')){ 
		if(*str==0) return false;
		ast(*str==32||*str==10||*str==13);
		++str;
	}
	while(*str>='0'&&*str<='9'){
		//printf("%d %p\n", *str, str);
		x = x*10+*str-'0';
		++str;
	}
	return true;
}
//Edge
void Edge::input(FILE *in){
	fscanf(in, "%d,%d,%d,%d,%d", &edgeID, &from, &to, &dis, &tm);
}
void Edge::output(){
	printf("%d %d %d %d %d\n", edgeID, from, to, dis, tm);
}
//Node
void Node::input(FILE *in){
	fscanf(in, "%d %d %lf %lf %lf %lf %d %d",
	&nodeID, &nodeType, &longitude, &latitude, &weight, &volume, &L, &R);
}
	//0 1 116.571614 39.792844 -1.0 -1.0 480 1440 
void Node::output(){
	printf("%d %d %.2lf %.2lf %.2lf %.2lf %d %d\n",
	nodeID, nodeType, longitude, latitude, weight, volume, L, R);
}
//VehicleInfo
void VehicleInfo::init(int _typeID, db _maxVolume, db _maxWeight, int _drivingRange, int _chargeTime, int _unitTransCost, int _vehicleCost){
	typeID = _typeID;
	maxVolume = _maxVolume;
	maxWeight = _maxWeight;
	drivingRange = _drivingRange;
	chargeTime = _chargeTime;
	unitTransCost = _unitTransCost;
	vehicleCost = _vehicleCost;
}
void VehicleInfo::output(){
	printSeparator();
	printf("typeID %d\n", typeID);
	printf("maxVolume %.2lf\n", maxVolume);
	printf("maxWeight %.2lf\n", maxWeight);
	printf("drivingRange %d\n", drivingRange);
	printf("chargeTime %d\n", chargeTime);
	printf("unitTransCost %d\n", unitTransCost);
	printf("vehicleCost %d\n", vehicleCost);
}
//VehiclePath
void VehiclePath::read(char *str){
	//puts("read");
	//puts(str);
	//char *p = str; while(*p) printf("%d ", *(p++));
	ast(str[1] == ':');
	str[1] = ' ';
	
	char *cur = str;
	path.clear();
	ast(readNonnegativeInt(cur, vehicleType) == true);
	int x; while(readNonnegativeInt(cur, x)) path.pb(x);
	ast(path[0] == 0); ast(path[sz(path)-1] == 0);
}
void VehiclePath::output(){
	printSeparator();
	printf("%d\n", vehicleType);
	rep(i, 0, sz(path)) printf("%d ", path[i]); putchar('\n');
}
